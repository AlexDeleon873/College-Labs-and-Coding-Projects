/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialinterface 
             Program Purpose/Description 
             {The pupose is to create a interface. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public interface deleonAInitialinterface
{
    public String personPantherID = "1234567";
    public String personLastName  = "Washington";
    public String personFirstName = "George";
     
    void thePersonSchool( String thePersonSchool );
    void thePersonPantherID( String thePersonPantherID );
    void thePersonLastName( String thePersonLastName );
    void thePersonFirstName( String thePersonFirstName );
     
}//end public interface deleonAInitialinterface



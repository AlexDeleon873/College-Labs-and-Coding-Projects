/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialSuperPgm3 
             Program Purpose/Description 
             {The pupose is to create a Super class that will be used with other programs. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonAInitialSuperPgm3
{

    private static void methodOne( int number )
    {
        System.out.printf( "%d\n", number );
    }//end private static void methodOne


    public void methodTwo( String stringOne, String stringTwo )
    {
        methodOne(5);
        System.out.printf( "%s\n", "I am super methodTwo" );
    }//end public void methodTwo


    public static void methodThree()
    {
       System.out.printf( "%s\n", "I am super methodThree" );
    }//end public static void methodThree

}//end public class deleonAInitialSuperPgm3
/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialSubOne 
             Program Purpose/Description 
             {The pupose is to create a sub-class that will be used with other programs. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonAInitialSubOne extends deleonAInitialSuperPgm3
{
    public void subOnePrint()
    {    
        System.out.printf( "%s\n", "I am sub-class One" );
    }//end public void subOnePrint
}//end public class deleonAInitialSubOne
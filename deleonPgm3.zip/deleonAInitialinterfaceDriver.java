/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialinterfaceDriver 
             Program Purpose/Description 
             {The pupose is to implement an interface. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonAInitialinterfaceDriver implements deleonAInitialinterface
{
    //implemetns interface varibles
    public static String personPantherID = "6226100";
    public static String personLastName  = "Deleon";
    public static String personFirstName = "Alexandria";
    //new global variable
    public static String school   = "FIU";
    
    public void thePersonSchool( String school )
    {
        System.out.printf( "%s\n", school );
    }//end public void thePersonSchool

    public void thePersonPantherID( String personPantherID )
    {
        System.out.printf( "%s\n", this.personPantherID );   
    }//end public void thePersonPantherID

    public void thePersonLastName( String personLastName )
    {
        System.out.printf( "%s\n", this.personLastName );    
    }//end public void thePersonLastName

    public void thePersonFirstName( String personFirstName )
    {
        System.out.printf( "%s\n", this.personFirstName );
    }//end public void thePersonFirstName

    public static void main( String args[] )
    {
        deleonAInitialinterfaceDriver driverObj = new deleonAInitialinterfaceDriver();

        driverObj.thePersonPantherID( personPantherID );
        driverObj.thePersonLastName( personLastName );
        driverObj.thePersonFirstName( personFirstName );
        driverObj.thePersonSchool(school);

    }//end main

}//end public class deleonAInitialinterfaceDriver
/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialDriverPgm3 
             Program Purpose/Description 
             {The pupose is to create a driver that will be used with other programs. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonAInitialDriverPgm3
{

    public static void main( String args[] )
    {
        //make objects for each of the classes and call the methods in the objects
        deleonAInitialSuperPgm3 superObject = new deleonAInitialSuperPgm3();

        superObject.methodTwo("Hello", "World");
        superObject.methodThree();

        deleonAInitialSubOne subOneObject = new deleonAInitialSubOne();
        
        subOneObject.subOnePrint();

        deleonAInitialSubTwo subTwoObject = new deleonAInitialSubTwo();
   
        subTwoObject.methodTwo("Hello", "World");

    }//end public static void main

}//end public class deleonAInitialDriverPgm3
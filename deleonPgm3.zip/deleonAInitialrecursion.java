/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP 3804
 Professor : Michael Robinson 
 Program   : deleonAInitialrecursion 
             Program Purpose/Description 
             {The pupose is to practice recursion and find factorial of 10. }

 Due Date  : 10/31/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

class deleonAInitialrecursion
{
    public static long factorial( int n )
    {
        System.out.printf( "Calling Step %d \n\n",  n );

        //System.out.printf( "     Dec   Total%s", "\n" );
       
        if( n <= 1 ) //base case
        {
            System.out.printf( "%8s%8s%s", "Dec", "Total", "\n" );
            return 1; 
        }
        else
        {     
            //doing recursion by calling factorial(n - 1)
            long counter = n * factorial(n - 1); 
            System.out.printf("%d! = %d*%d! =  " + " %d\n",  n, n, (n-1), counter );
                    
            return counter;
        }
             
    }//end public static long fact(long n)
                   

    public static void main(String args[])
    {
     
        System.out.printf( "\nThe factorial of 10 = " + 
                            factorial( 10 ) );
    }//end public static void main(String args[])
    
}//end class recursion
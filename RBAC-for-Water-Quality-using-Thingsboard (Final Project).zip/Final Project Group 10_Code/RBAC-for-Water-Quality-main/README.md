# RBAC-for-Water-Quality

Dataset from Kaggle:
https://www.kaggle.com/datasets/sahirmaharajj/water-quality-data

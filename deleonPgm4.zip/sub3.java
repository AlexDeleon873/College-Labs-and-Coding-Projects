/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This is a sub class of the deleonASuperPgm4 super class}

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class sub3 extends deleonASuperPgm4
{


}//end public class sub3
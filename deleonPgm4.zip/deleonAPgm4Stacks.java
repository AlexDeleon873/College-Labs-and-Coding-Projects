/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This program showcases stack sorting. }

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/
import java.util.*;

public class deleonAPgm4Stacks 
{
    public static void printTheStack( Stack<String> stack, String message )
    {
        if( !stack.empty() )
        {
            System.out.printf( "  %s = %d\n",
                               message, stack.size() );
        }
    
    }//end public static void printTheStack( Stack<String> stack, String message )
       
       
    public static void stackPop( Stack<String> stack )
    {
    
        String message = "\n  deleting stack item =";
      
        while ( !stack.empty() )
        {
            //sees item on top
            System.out.printf( "\n  Item on top of the stack = %s",  
                               (String)stack.peek() );

            System.out.printf( "\n  Amount of items in stack = %d ", stack.size() );
           
            //find and remove the last element from the stack
           System.out.printf( "  %s %s\n",
                               message, (String)stack.pop() );
               
           System.out.printf( "  Items inside the stack = %s  stack size = %d\n ", stack, stack.size() );
        }
        
        System.out.printf( "\nNow we have an empty stack," +
                           " size = %d, items = %s\n",
                             stack.size(), stack );
        
    }//end public static void stackPop( Stack<String> stack )
    
    
    public static void fullStack( Stack<String> stack )
    {    
        System.out.printf( "\n  These are the items in my stack\n" );
                
        System.out.printf( "  Full stack = %s of size = %d\n\n", 
                              stack, stack.size() );
          
        String item = "";
       
        Iterator iter = stack.iterator();
         
        while(iter.hasNext())
        {
            item = (String)iter.next();
            System.out.printf( "  I am at location %d which contains : %s.\n", stack.search( item ), item );
        }
        
        System.out.printf( "%s", "\n" );
        
        
        //enhanced for  loop processes the stack object
        for( String temp : stack)
        {
            System.out.printf( "  I am at location %d which contains : %s.\n", stack.search( temp ), temp );
        }
        
       
        
    }//end public static void fullStack( Stack<String> stack )
    
    
    public static void stackPush( Stack<String> stack )
    {
        System.out.printf( 
                  "My current stack size is : %s\n\n", stack.size() );

        String message = "Adding WORD VALUE into the stack, current stack size ";
    
        stack.add( "Cool" );
        printTheStack( stack, message );
            
        stack.add( "Awesome" );
        printTheStack( stack, message );

        stack.add( "Nice" );
        printTheStack( stack, message );
          
        stack.add( "Yes" );
        printTheStack( stack, message );
    
        stack.add( "Cat" );
        printTheStack( stack, message );
          
        stack.add( "Snapdragon" );
        printTheStack( stack, message );
        
    }//end public static void stackPush( Stack<String> stack )
    
    
    public static void  main( String arg[] )
    {
        //creating an object called stack
        Stack<String> stack = new Stack<String>();
           
        //call the method stackPush( stack )   
        stackPush( stack );
           
        //call the method fullStack( stack )              
        fullStack( stack );
      
        //call the method stackPop( stack )              
        stackPop( stack );

    }//end public static void  main( String arg[] )
    
}//end public class deleonAPgm4Stacks

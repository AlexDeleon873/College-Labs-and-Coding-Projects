/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This is a sub class of sub2/Super2 class that displays all methods of the deleonASuperPgm4 super class only plus the words 
I am TheBuilder."}

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/


public class deleonATheBuilder extends sub2
{
    public void theBuilderDisplay()
    {   
        super.method2("Hello", "World");
        super.method3();

        System.out.printf( "%s\n", "I am TheBuilder" );
    }//end public void deleonATheBuilder
}//end public class deleonATheBuilder
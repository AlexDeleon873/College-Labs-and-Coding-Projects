/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This driver class uses all previous methods in all classes for program 4. }

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonATheDriverPgm4
{

    public static void main( String args[] )
    {
        //make objects for each of the classes and call the methods in the objects
        deleonASuperPgm4 superObject = new deleonASuperPgm4();

        superObject.method2("Hello", "World");
        superObject.method3();

        sub1 subOneObject = new sub1();
        subOneObject.method2("Hello", "World");
        subOneObject.method3();

        sub2 subTwoObject = new sub2();
        subTwoObject.method2("Hello", "World");
        subTwoObject.method3();

        sub3 subThreeObject = new sub3();
        subThreeObject.method2("Hello", "World");
        subThreeObject.method3();


        deleonATheBuilder builderObject = new deleonATheBuilder();
        
        builderObject.theBuilderDisplay();


        deleonAOverloader overloaderObject = new deleonAOverloader();

        overloaderObject.method2("Hello", "World");
   

    }//end public static void main

}//end public class deleonAInitialDriverPgm3
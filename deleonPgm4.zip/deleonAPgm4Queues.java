/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This program showcases queue sorting. }

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/
import java.util.*;


public class deleonAPgm4Queues 
{
    public static void printTheQueue(Queue<String> queue, String message )
    {
        System.out.printf( " Adding WORD VALUE into the queue, current queue size = %d\n", queue.size() );
    }


    public static void reqularQueue()
    {
        String message = "Adding items is the queue,";

        Queue<String> queue = new LinkedList<String>();
           
        System.out.printf( "My current queue size is: %s\n\n", queue.size() );
            
        queue.add( "Cherry" );
        printTheQueue( queue, message );
             
        queue.add( "Apple" );
        printTheQueue( queue, message );
         
        queue.add( "Peach" );
        printTheQueue( queue, message );
             
        queue.add( "Banana" );
        printTheQueue( queue, message );

        queue.add( "Watermelon" );
        printTheQueue( queue, message );

        queue.add( "Strawberry" );
        printTheQueue( queue, message );
          
        
        System.out.println( "\n These are the items in my queue" );
        Iterator itq = queue.iterator();

        System.out.printf( " Full queue %s\n\n", queue );
                 
           
        Iterator itqProcess = queue.iterator();
        int counter = 1;
        
        while( itqProcess.hasNext() ) 
        { 
            System.out.printf( "   I am at location %d which contains : %s\n ", counter, ( String )itqProcess.next() );
            counter++;
        }

        System.out.printf( "%s", "\n" );

        counter = 1;
        //enhanced for  loop processes the queue object
        for(String temp : queue)
        {
            System.out.printf( "  I am at location %d which contains : %s.\n", counter, temp );
            counter++;
        }


        while ( queue.size() != 0)
        {
            // .peek sees what's on top
            System.out.printf( "\n  Item on top of the queue = %s", (String)queue.peek() );

            System.out.printf( "\n  Amount of items in queue = %d ", queue.size() );
           
            //find and remove the last element from the queue
            System.out.printf( "\n  deleting queue item = %s\n", (String)queue.remove() );
               
            System.out.printf( "  Items left inside the queue = %s  queue size = %d\n ", queue, queue.size() );
        }
        
        System.out.printf( "\nNow we have an empty queue, size = %d, items = %s\n", queue.size(), queue );
         
    }//end  public static void reqularQueue()
     
         
    public static void main(String[] args) 
    {
       reqularQueue();
       
    }//end public static void main(String[] args)

    
}//end public class deleonAPgm4Queues 

/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This sub class contains all methods from deleonASuperPgm4 while overriding method two. }

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonAOverloader extends deleonASuperPgm4
{
    @Override
    public void method2(String one, String two)
    {
        System.out.printf( "%s\n", "Hello I am the Overloader" );   
    }//end public void method2
}//end public class deleonAOverloader
/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This is a super class that will inherit other programs.}

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonASuperPgm4
{

    private static void method1( int number )
    {
        System.out.printf( "%d\n", number );
    }//end private static void method1


    public void method2( String stringOne, String stringTwo )
    {
        method1(7);
        System.out.printf( "%s, %s, %s\n", stringOne, stringTwo, "I am super method2" );
    }//end public void method2


    public static void method3()
    {
        System.out.printf( "%s\n", "I am super method3" );
    }//end public static void method3

}//end public class deleonASuperPgm4
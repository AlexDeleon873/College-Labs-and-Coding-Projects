/*********************************************************************
 Author    : Alexandria Deleon 
 Course    : COP3804
 Professor : Michael Robinson 
 Program #4 : Program 4
 Purpose   : Purpose/Description 
             {This program demonstrates polymorphism as well as swaping, sorting, stacks, and queues.}

 Due Date  : 11/23/2023 


 Certification: 
 I hereby certify that this work is my own and none of it is the work of any other person. 

 ..........{ Alexandria Deleon }..........
*********************************************************************/

public class deleonApgm4
{         


    public static void swapThem( int firstNum, int secondNum, int thirdNum, int fourthNum )
    {
        int temp = 0;

        if( firstNum > secondNum )
        {
            temp      = firstNum;
            firstNum  = secondNum;
            secondNum = temp;
        }

        if( secondNum > thirdNum )
        {
            temp      = secondNum;
            secondNum = thirdNum;
            thirdNum  = temp;
        }

        if( thirdNum > fourthNum )
        {
            temp      = thirdNum;
            thirdNum  = fourthNum;
            fourthNum = temp;
        }

        if( firstNum > secondNum )
        {
            temp      = firstNum;
            firstNum  = secondNum;
            secondNum = temp;
        }

        if( secondNum > thirdNum )
        {
            temp      = secondNum;
            secondNum = thirdNum;
            thirdNum  = temp;
        }

        System.out.printf( "%d, %d, %d, %d\n", firstNum, secondNum, thirdNum, fourthNum );

    }//public static void swapThem


    public static void BubbleSort()
    {
        String myName[] = {"Deleon", "Alexandria" };
        
        System.out.printf( "%s", "\nOriginal: ");

        for( String d : myName )
        {
            System.out.printf( "%s", d );
        }
            
        
        //this compares x and x+1, swaping depending on which comes first alphabetically
        for( int x= 0; x < myName.length; x++ )
        {
            for( int y = x + 1; y < myName.length; y++ )
            {

            String swap;

                if( myName[x].compareTo(myName[y])>0 )
                {
                    swap = myName[x];
                    myName[x] = myName[y];
                    myName[y] = swap;

                }
            }
 
        }

        System.out.printf( "%sSorted: ", "\n");
 
        for( String d : myName )
        {
            System.out.printf( "%s", d );
        }
         
    }//public static void BubbleSort


    public static void main( String arg[] )
    {
        int firstNum  = 784;
        int secondNum = 5;
        int thirdNum  = 123;
        int fourthNum = 56;
    
        System.out.printf( "%d, %d, %d, %d\n", firstNum, secondNum, thirdNum, fourthNum );

        swapThem( firstNum, secondNum, thirdNum, fourthNum );

        BubbleSort();
    }//public static void main

}

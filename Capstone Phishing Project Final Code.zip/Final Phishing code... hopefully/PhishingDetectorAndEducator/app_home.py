import streamlit as st
import pandas as pd
import datetime as dt

st.set_page_config(page_title="Home")

st.title("Welcome to PhishTrap")
st.subheader("Trust us so you can trust the internet")

st.write("Welcome to PhishTrap, a online Phishing Detection analysis tool that currates to the most highest standrads.")
st.write("To left you have our wide variety of tools.")
st.write(" You have the option to to manually paste a suspious URL or message you recieved")
st.write("Or you can connect your email to automatcally grab your phishy email and well be able to dechiper it")
st.write("Below you will see our weekly detection as its being collected by every user, we tracking which are the most common attemtps to make our algorithm better ")

#Chart displaying scans of the week
st.title("Scans of the week")
df = pd.read_csv("history.csv")

df["Date"]=pd.to_datetime(df["Date"], format="%a, %b %d %Y at %I:%M").dt.date

df["days"] = pd.to_datetime(df["Date"]).dt.day_name()
df["days"] = pd.Categorical(df["days"],categories=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], ordered=True)

count_scans_weekly = df.groupby("days", observed=False)["URL"].count()

st.bar_chart(count_scans_weekly)





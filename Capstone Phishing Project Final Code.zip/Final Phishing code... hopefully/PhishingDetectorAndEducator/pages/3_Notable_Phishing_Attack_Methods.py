import streamlit as st

st.title("Notable Phishing Attack Methods")

st.write("")

st.subheader("Email Phishing")
st.write("Attackers send fraudulent emails impersonating legitimate organizations, often containing malicious links or attachments.")

st.subheader("Spear Phishing")
st.write("A targeted phishing attack directed at a specific individual or organization, using personalized information to appear legitimate.")

st.subheader("Business Email Compromise (BEC)")
st.write("Attackers compromise or spoof corporate email accounts to trick employees into transferring money or sensitive data.")

st.subheader("Smishing (SMS Phishing)")
st.write("Phishing via text messages, often containing malicious links or requests for sensitive information.")

st.subheader("Vishing (Voice Phishing)")
st.write("Attackers use phone calls to trick victims into revealing sensitive information.")
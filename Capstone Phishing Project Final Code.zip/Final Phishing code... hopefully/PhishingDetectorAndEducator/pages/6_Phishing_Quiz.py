import streamlit as st
import streamlit_book as stb

st.set_page_config()

st.title("Phishing Attack Quiz!")

st.markdown("---")
stb.single_choice("What is Smishing (SMS Phishing)?",
                  ["Attackers send fraudulent emails impersonating legitimate organizations, often containing malicious links or attachments.", "Attackers compromise or spoof corporate email accounts to trick employees into transferring money or sensitive data.", "Attackers use phone calls to trick victims into revealing sensitive information.", "Phishing via text messages, often containing malicious links or requests for sensitive information."],
                  3)

st.markdown("---")
stb.single_choice("What is Email Phishing?",
                  ["Attackers use phone calls to trick victims into revealing sensitive information.", "Attackers send fraudulent emails impersonating legitimate organizations, often containing malicious links or attachments.", "A targeted phishing attack directed at a specific individual or organization, using personalized information to appear legitimate.", "Phishing via text messages, often containing malicious links or requests for sensitive information."],
                  1)

st.markdown("---")
stb.single_choice("What is Buisness Email Compromise (BEC)?",
                  ["Attackers compromise or spoof corporate email accounts to trick employees into transferring money or sensitive data.", "Phishing via text messages, often containing malicious links or requests for sensitive information.", "A targeted phishing attack directed at a specific individual or organization, using personalized information to appear legitimate.", "Attackers use phone calls to trick victims into revealing sensitive information."],
                  0)

st.markdown("---")
stb.single_choice("What is Vishing (Voice Phishing)",
                  ["A targeted phishing attack directed at a specific individual or organization, using personalized information to appear legitimate.", "Attackers use phone calls to trick victims into revealing sensitive information.", "Phishing via text messages, often containing malicious links or requests for sensitive information.", "Attackers send fraudulent emails impersonating legitimate organizations, often containing malicious links or attachments."],
                  1)

st.markdown("---")
stb.single_choice("What is Spear Phishing",
                  ["Attackers compromise or spoof corporate email accounts to trick employees into transferring money or sensitive data.", "Phishing via text messages, often containing malicious links or requests for sensitive information.", "A targeted phishing attack directed at a specific individual or organization, using personalized information to appear legitimate.", "Attackers compromise or spoof corporate email accounts to trick employees into transferring money or sensitive data."],
                  2)
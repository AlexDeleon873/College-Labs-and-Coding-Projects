import streamlit as st

st.title("Phishing")
st.divider()

st.subheader("What is Phishing")
long_text = """
Phishing is a cyberattack where cyber criminals pretend to be someone their not to trick you into giving up sensitive information
like credit cards, bank details, account usernames and passwords, the list goes on. Phishing can be done through phone calls, emails, text messages and through on social media. 
"""
st.write(long_text)

st.subheader("How Phishing Works")
long_text2 = """
Phishing uses social engineering, which is referred to as psychological manipulation. A story is created and the person is acing as someone else, tech support, employee, bank teller, etc... After that there usually there is a link attached to the email and they insist you click it immediately to resolve the issue they made up. Now that link will either download malware to your computer or send you to a spoofed website of a popular site that is identical to the real website and ask you to sign in so they can steal your credentials and either sell it or use it themself to access your account. The biggest tactic social engineers or phishing has is using a sense of urgency in their story, meaning using terms regarding time like: "Account will be deleted in 24 hours if you don't respond", or "Sign in to your PayPal account or you have 20 minutes to unsend this payment to Jared." 
"""
st.write(long_text2)

st.subheader("History of Phishing")
long_text3 = """
The term phishing comes from fisherman, and how when they fish they use bait to catch the fish. Similar a criminal will use bait, a email instead of worms, to catch a victim into giving up their sensitive data. 

From https://www.graphus.ai/blog/history-of-phishing/, they talked about the first person to use phishing. The story falls back to an old well known hacker named Khan C. Smith, who wrote a story in a newspaper article about AOLs breach. The story is, scammer were able create an algorithm that will generate random credit cards credentials to open AOL accounts and then proceeded to spam users inboxes with fake messages asking them to verify billing details, or account details. 
"""
st.write(long_text3)

st.subheader("Tips to Stay Safe")
st.write("TIP: Verify Sender Email: Always check the sender's email address for discrepancies. Phishing emails often mimic legitimate addresses but may have slight variations.")
st.write("TIP: Hover Before Clicking: Hover over links to see the actual URL. If it looks suspicious or doesn’t match the supposed destination, don't click it.")
st.write("TIP: Look for Generic Greetings: Phishing emails often use generic salutations like 'Dear Customer' instead of your name.")
st.write("TIP: Beware of Urgency: Phishing attempts often create a sense of urgency, claiming immediate action is required. Take your time and verify before responding.")
st.write("TIP: Check for Spelling Errors: Legitimate companies usually proofread their communications. Spelling mistakes and awkward phrasing can indicate a phishing attempt.")
st.write("TIP: Don't Open Unexpected Attachments: If you receive an attachment from an unknown sender, do not open it, as it could contain malware.")
st.write("TIP: Use Two-Factor Authentication (2FA): Enable 2FA on your accounts to add an extra layer of security, even if your password is compromised.")
st.write("TIP: Report Suspicious Emails: If you receive a suspicious email, report it to your email provider and delete it.")
st.write("TIP: Use a Password Manager: Password managers can help you create strong passwords and store them securely, reducing the risk of phishing.")
st.write("TIP: Be Cautious of Links in Social Media Messages: Phishing attempts can occur on social media platforms. Always verify links before clicking.")
st.write("TIP: Limit Personal Information Online: Be mindful of what personal information you share online, as it can be used in phishing attempts.")
st.write("TIP: Look for Unusual Requests: Be suspicious of emails asking for personal information or payment details, especially if they seem out of the ordinary.")
st.write("TIP: Secure Your Email Account: Use a strong, unique password for your email account to prevent unauthorized access.")
st.write("TIP: Verify Claims of Suspicious Activity: If an email claims there’s been suspicious activity on your account, contact the company directly using verified contact methods.")
st.write("TIP: Educate Others: Share tips and knowledge about phishing with friends and family to help them stay safe online.")
st.write("TIP: Check for Review and Feedback: Look up reviews or feedback on unfamiliar websites before making purchases or entering personal information")



st.subheader("Types of Phishing, Next page ---->")


import os.path
import re
import streamlit as st
from URL_scan import scan_url, VT_API, scan_url_gsb, google_SB_API, scan_url_report
import time
from time import gmtime, strftime
from gemini_ai import generate
import csv
import pandas as pd
import whois
from datetime import datetime, timedelta, date
from urllib.parse import urlparse



#-------------SAVE URL HISTORY -------------------------------
def save_history(man_url_input, date_formated):
    fieldnames = ["URL", "Date"]

    with open("history.csv", mode='a', newline='') as csvfile: #use 'a' to append to each row as a new line
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames) #writes to file with the headers
        writer.writerow({"URL": man_url_input, "Date": date_formated}) #writes data into headers
#-------------------------------------------------

#-------------GET THE FINAL RESPONSE IF ITS PHISHING OR NOT FROM GEMINI----------------------------
def get_final_verdict(gemini_response):
    start_of_verdict = gemini_response.find("FINAL_VERDICT : ") #find keyword in whole doc
    if start_of_verdict == -1:
        start_of_verdict = gemini_response.find("THE_FINAL_VERDICT: ")
        if start_of_verdict == -1:
            st.error("Final veridct not found")


    text = gemini_response[start_of_verdict:].strip() # removes everything before to keep the sentence with final verdict
    end_of_verdict = text.find("!") #looks for !, bc its specific to the prompt and easy to spot
    if end_of_verdict == -1:
        st.error("unable to find verdict")

    verdict = text[len("FINAL_VERDICT:"):end_of_verdict].strip() #removes after to get the final verdict

    st.info(verdict)
#--------------Rules for safety check point system for phishtrap option----------------------------------
def url_rules(man_url_input):

    url_results = {} #creates dictonary to hold all results

    #all true or false
    url_results["check_for_https"] = man_url_input.startswith("https://")

    url_results["check_length"] = len(man_url_input) < 60 #check if url length is longer than 60 charcters

    special_characters = "@_!#$%^&*()<>?/|}{~:"
    chars_pattern = re.escape(special_characters)# saying to regex this is just a string of characters not commands
    url_results["check_for_special_chars"] = bool(re.search(chars_pattern, man_url_input))

    random_str = r"/[A-Za-z0-9]{7,}"#if finds the string is more than 7 characters
    url_results["check_for_string_chars"] = bool(re.search(random_str, man_url_input))

    return url_results
#--------------Handles whois functions for the 30 days date check----------------------------------
def lookup(man_url_input):
    parse_this_url = man_url_input #sets url up to be parsed

    #res = whois.whois("www.google.com")
    parsed_url = urlparse(parse_this_url) #grabs the url and uses urllib parse and to get only the domain
    domain_name = parsed_url.netloc
    st.write(f"`{domain_name}`")

    try:
        w = whois.whois(domain_name)
        creation_date = w.creation_date #using whois to grab the creation date
        if isinstance(creation_date, list): #check if date is in list
            creation_date = creation_date[0] #grabs the first one
        creation_date = creation_date.date() #convert the date
        st.write(f"Creation Date: {creation_date}")

        current_date = datetime.today().date() #grab todays date
        st.write(f"Today's Date: {current_date}")

        date_difference = current_date - creation_date #subtracts the date created - the date of today
        #st.write(f"Difference: {date_difference}")
        years_difference = date_difference.days / 365.25
        st.write(f"There has been {date_difference.days} days since creation date, or {years_difference:.2f} years since creation date")

        if date_difference < timedelta(days=30):#time delta is how to represent subrtacting two different times
            st.error("This url has been created in the past 30, label=bad")
        else:
            st.success("This url was created a while ago, label=good")
    except Exception as e:
        print(f"Exception: {e}")

#---------------Second who is look up for extra information-----------------------------
def lookup2(man_url_input):
    w = whois.whois(man_url_input) #just getting all whois data that seems relevent
    # print(res)
    st.write("Organization ", w.domain_name)
    st.write("Creation Date ",w.creation_date)
    st.write("Date Updated ", w.updated_date)
    st.write("Experation Date ",w.expiration_date)
    st.write("Subdomains ", w.subdomain)
    st.write("Online Status ",w.status)
    st.write("Servers ", w.name_servers)

    st.write("Country ",w.country)
    st.write("State ID ",w.state)
    st.write("City ",w.city)

    st.write("Registrar ",w.registrar)
    st.write("Registrar URL ",w.registrar_url)
    st.write("Registrar Email ",w.registrar_email)
    with st.expander("FULL JSON REPORT"):
        st.json(w)
    #print(w.emails)
#----------------------------------------

st.header("URL Scan")

tab1, tab2, tab3 = st.tabs(["URL check", "Email check", "History"]) # creates the tabs to switch through

with tab1:#who page initally starts on page 1
    st.title("URL Scan")

    # For debugging, show if the API key is loaded or not
    if not VT_API:
        st.error("API Key not loaded from .env file")
        st.write("Check your .env file")
    else:
        st.success("API Key loaded successfully.")

    if not google_SB_API:
        st.error("API Key not loaded from .env file")
        st.write("Check your .env file")
    else:
        st.success("API Key loaded successfully.")

    st.caption("Please be sure that the link you are submitting does not contain any sensitive information" +
               " that may relate back to you, like tracking numbers. Anything submitted will be run through VirusTotal publicly")

    api_choice = st.selectbox("API OPTION", ("VirusTotal", "PhishTrap Combination"), index=None, placeholder="Choose below to get started",)
    man_url_input = st.text_input("Paste the URL here:")

    if st.button("Scan"):
        if man_url_input:
            if api_choice == "VirusTotal":
                with (st.spinner("Scanning URL...")): # for UI fun
                    result = scan_url(man_url_input) # this one gets the stats for the board and chart
                    result_report = scan_url_report(man_url_input) # this one gets all other info about the url
                    if result:
                        try:
                            attributes = result.get("data", {}).get("attributes", {}) #following the json responose structure to get what we need
                            stats = attributes.get("stats", {})

                            st.subheader(f"Scan Summary of `{man_url_input}`")

                            #------for viewing the reponse from virus total------------------
                            col1, col2, col3, col4 = st.columns(4)

                            #pulling from stats section in json and turning everything into a metric from streamlit
                            col1.metric("Malicious", stats.get("malicious", 0), border=True)
                            col2.metric("Suspicious", stats.get("suspicious", 0), border=True)
                            col3.metric("Harmless", stats.get("harmless", 0), border=True)
                            col4.metric("Undetected", stats.get("undetected", 0), border=True)

                            #------script to find the total
                            total_engines = sum(stats.values())

                            create_score = total_engines - stats.get("undetected", 0)
                            check_for_undetected = total_engines - create_score

                            st.write(f"There are a total of {total_engines} vendors but {check_for_undetected} vendors that went undetected, they have been removed from the score.")
                            st.caption("But be vigilante still. Just because its a undetected score, doesnt mean the url is "
                                     "safe or not safe, just not scanned.")

                            #-----creating a rating system
                            rating = (create_score / total_engines) * 100

                            if rating >= 70:
                                st.success("URL IS DEEMED SAFE. (Harmless/Total) " + str(stats.get("harmless")) + f"/ {create_score}")
                            if rating in range(39,61): #compares between number 39 and 60
                                st.warning("URL seems to have been flagged by some vendors, URL IS DEEMED SUSPICIOUS. Procceed"
                                           " with caution and check the details below for a added assessment")
                            if rating < 30:
                                st.warning("URL IS DEEMED UNSAFE, stay away from this url. " + str(stats.get('malicious')) +
                                           f"/ {str(stats.get('suspicious'))} / {str(stats.get('harmless'))} / {create_score}")

                            #st.info(f"Total engines: {total_engines}")

                            #-------setting the timestamp into human readable / organized form-------
                            timestamp = attributes.get("date", "Unknown")
                            date_scanned = datetime.fromtimestamp(int(timestamp))
                            date_formated = date_scanned.strftime("%a, %b %d %Y at %I:%M")
                            st.info(f"Date Scanned: " + date_formated)

                            st.subheader("Detailed Results")

                            #st.divider()

                            #---------This sections off results making it organzed to read through------
                            tabA, tabB, tabC, tabD = st.tabs(["ALL ENGINES", "HARMLESS RESULTS", "SUSPICIOUS & MALICIOUS", "TOP ENGINES"])

                            full_engine_results_only = [] # create empty to list to add too
                            anaylsis_results = attributes.get("results", {}) #get the results
                            for engine_name, data in anaylsis_results.items(): # filters out the info we need and loops
                                category = data.get("category")
                                method = data.get("method", "No results")
                                engine_result = data.get("result", "No results")

                                full_engine_results_only.append({ #appeneds it to the list
                                    "Engine": engine_name,
                                    "Category": category,
                                    "Method": method,
                                    "Results": engine_result
                                })

                            # ---------create a panda dataframe--------- then inside creates a streamlit table
                            full_engine_results_only_df = pd.DataFrame(full_engine_results_only)
                            #ALL ENGINE RESULTS
                            with tabA:
                                st.subheader("Check what your favorite engines have to say")
                                st.caption("You can also search for them in the table")
                                st.dataframe(full_engine_results_only_df)

                            with tabB:
                                harmless_filter = full_engine_results_only_df[full_engine_results_only_df["Category"] == "harmless"]
                                st.dataframe(harmless_filter)

                            with tabC:
                                sus_and_mal_filter = full_engine_results_only_df[full_engine_results_only_df["Category"].isin(["suspicious", "malicious"])]
                                st.dataframe(sus_and_mal_filter)

                            with tabD:
                                st.subheader("See what some of most reputable engines said about your URL")

                                #some of the best vendors/engines in the phishing field
                                key_vendors = ["BitDefender", "ESET", "Kaspersky", "Sophos", "Webroot",
                                               "Google Safe Browsing", "AlienVault", "Trustwave", "Fortinet",
                                               "Phishtank", "OpenPhish", "Mimecast", "Netcraft"]
                                top_vendors_filter = full_engine_results_only_df[full_engine_results_only_df["Engine"].isin(key_vendors)]
                                st.dataframe(top_vendors_filter)


                            #------this is getting more information from the virustotal api report-------
                            st.divider()
                            attributes = result_report.get("data", {}).get("attributes", {}) #initalizing to follow path of a different report to get all data below

                            first_submission_date = attributes.get("first_submission_date")
                            first_submission_date_scanned = datetime.fromtimestamp(int(first_submission_date))
                            first_submission_date_formatted = first_submission_date_scanned.strftime("%a, %b %d %Y at %I:%M")

                            last_analysis_date = attributes.get("last_analysis_date")
                            last_analysis_date_scanned = datetime.fromtimestamp(int(last_analysis_date))
                            last_analysis_date_formatted = last_analysis_date_scanned.strftime("%a, %b %d %Y at %I:%M")

                            times_submitted = attributes.get("times_submitted",0)
                            redirection_chain = attributes.get("redirection_chain")
                            final_url = attributes.get("last_final_url")

                            url_title = attributes.get("title")
                            url_description = attributes.get("html_meta").get("description")
                            url_category_labels = attributes.get("categories")
                            top_level_domain = attributes.get("tld")
                            total_community_votes = attributes.get("total_votes")

                            #-----Extra details information--------
                            col1, col2 = st.columns(2)

                            with col1:
                                st.subheader("Submission History")
                                st.write(f"First Submission: {first_submission_date_formatted}")
                                st.write(f"Most Recent Submission: {last_analysis_date_formatted}")
                                st.write(f"This url has been submitted {times_submitted} times since first scanned")

                                st.subheader("Redirection and Final URL")
                                st.write(f"All redirection links if any: `{redirection_chain}`")
                                st.write(f"Final URL landing: `{final_url}`")

                            with col2:
                                st.subheader("Extra Details")
                                st.write(f"The Top level domain of the website: {top_level_domain}")
                                st.write(f"The Title of the website: {url_title}")
                                st.write(f"The Description of the website: {url_description}")
                                st.write(f"The Categories vendors have labeled the website:")
                                for engine_name, tags in url_category_labels.items():
                                    st.write(f"{engine_name}: {tags}")
                                st.write(f"Community votes: {total_community_votes}")

                            with st.expander("FULL JSON REPORT"):
                                st.json(result_report)

                        #if all fails return to json form
                        except Exception as e:
                            st.error(f"Error parsing results: {str(e)}")
                            st.json(result)
                            #ask for a rescan

                        save_history(man_url_input, date_formated) #saves the input and date into the csv

            #-----------users second option----------
            elif api_choice == "PhishTrap Combination":
                st.caption("Phishtrap combination uses Google Safebrowsing to first check if the email is on their list,"
                           " It then begins a whois scan to get some data out of it. Finally we have designed a point and "
                           "check system of the url to determine the final result.")
                with st.spinner("Scanning URL..."):
                    safety_point = 0 # initialize variable for points
                    time.sleep(2) # wait to continue showing response

                    url_rules_results = url_rules(man_url_input) #calls url rules function and gets the reuslts dict

                    #-------mini test score to help create piece of mind besides googles safe browsing-----
                    if url_rules_results["check_for_https"] == True:
                        safety_point += 1
                    else:
                        safety_point += 0
                    if url_rules_results["check_length"] == True:
                        safety_point += 1
                    else:
                        safety_point += 0
                    if url_rules_results["check_for_special_chars"] == False: # use false because we want it to be false so false is the true version / response we want
                        safety_point += 1
                    else:
                        safety_point += 0
                    if url_rules_results["check_for_string_chars"] == False:
                        safety_point += 1
                    else:
                        safety_point += 0

                    #getting google safe browsing reponse, setting the points to 3, pretty much making the score rely on GSB
                    result_GSB = scan_url_gsb(man_url_input)
                    print(result_GSB, "safe") # confirms safe alongside response back of {}

                    if result_GSB == {}: #how google responds back after post if safe
                        safety_point += 3
                        st.success("No matches found in Googles Safe Browsing: URL is safe")
                    else:
                        safety_point += 0
                        threat_match = True
                        matches = result_GSB["matches"]
                        st.error("Matches found: Threats Detected, URL might be unsafe")

                        st.json(result_GSB)

                    #Safety Points and if the socre is more than 5 its good.
                    st.subheader(f"Scan Summary of `{man_url_input}`")
                    print(safety_point)
                    st.json(url_rules_results)
                    if safety_point > 5:
                        st.success("This url is safe")
                    else:
                        st.error("This url is not safe")

                    st.divider()
                    st.subheader("Checking Domain Creation Information")
                    st.write(lookup(man_url_input))
                    st.divider()
                    st.subheader("Domain Information")
                    st.write(lookup2(man_url_input))


        else:
            st.warning("No URL, try again or a different URL")


#-------for pasting an email into the website, all coming from gemini util file-------
with tab2:
    st.title("Email Scan")
    man_email = st.text_area("Paste the message here", height= 300)
    if st.button("Submit"):
        with st.spinner(""):
            if man_email:
                gemini_response = generate(man_email)
                st.write(gemini_response)
                st.caption("Produced by gemini")

#-------for history section-------
with tab3:
    st.title("History")
    df = pd.read_csv('history.csv')
    st.dataframe(df)

    st.divider()

    #vertical columns, badges,



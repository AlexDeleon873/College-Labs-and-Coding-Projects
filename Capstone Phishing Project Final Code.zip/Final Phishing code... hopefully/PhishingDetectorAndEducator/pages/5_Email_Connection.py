import streamlit as st
from get_emails import fetch_emails
from gemini_ai import generate


#-------------keeps session states active so that if you switch pages or scan an email you dont have to refetch-----
if "email_details" not in st.session_state:
    st.session_state.email_details = []

#if "delete_emails" not in st.session_state:
    #st.session_state.delete_emails = ()

if "scan_emails" not in st.session_state: #when u scan you actually get the response to show up
    st.session_state.scan_emails = {}

#----------------------------------------------------------
st.title("Email Inbox Viewer")

#-----------gets email from get_email function.------
if st.button("Check Emails"):
    st.session_state.email_details = fetch_emails()


if st.session_state.email_details:
    #A search feature to be added later

    #Search = st.text_input("Search for specific queries here:", placeholder="'example@example.com, 'Login Attempt', 'apr 8th'")
    #with st.popover("Search --help"):
        #st.caption("Search through these methods below:")
        #st.caption("---------")
        #st.caption("-From")
        #st.caption("-Subject")
        #st.caption("-ON 'Date'")
        #st.caption("-ID")



    st.markdown("---")

    #running through writing the pulled data
    for index, email_data in enumerate(st.session_state.email_details):
        st.caption(f"Email-ID {index + 1}" + ", " + f"**Date**: {email_data['Date']}")
        st.write(f"**From**: {email_data['From']}")
        st.write(f"**Subject**: {email_data['Subject']}")

        contents = email_data['Content']
        with st.expander("**Message**", expanded=True):
            st.write(contents)

        col1, col2 = st.columns(2)

        if col1.button("Scan", key=f"scan_fetched_email{index}"): #button that initiates gemini to run, index is to following same path down as email id to get through every email correctly
            gemini_response = generate(contents) #grabs content from email, which is the actual message / body
            st.session_state.scan_emails[index] = gemini_response
            with st.expander("**Response**", expanded=True): #** turns the word to bold
                st.write(st.session_state.scan_emails[index])
                st.caption("Produced by gemini")

        #if col2.button("Delete", key=f"delete_fetched_email{index}"):
            #delete_emails(email_data["uid"])


        st.markdown("---")

import base64
import os
from google import genai
from google.genai import types
from dotenv import load_dotenv

load_dotenv()

#-----This is the prompt that gemini will follow after being a email was submitted
prompt = """ 
FOLLOW THIS PROMPT, AS IT WILL BE ASKED MULTIPLE TIMES AS YOU ARE BEING ASKED TO SCAN AN EMAIL.
I am providing you with an email text to analyze for potential phishing, grammar, spelling, keywords, and overall structure. 
Your task is to break down the email sentence by sentence, identify keywords typically associated with phishing, and explain why they might indicate phishing. Then, check the grammar and spelling across the email. 
Finally, perform an overall analysis summarization of your own and provide a final verdict on whether the email is likely phishing or not. 
Keep it brief/short, yet informational. 
Structure your response exactly as follows, organize it where its easy to read using bullets if necessary:

KEYWORDS & SENTENCES:
For each sentence in the email, list the sentence verbatim, then identify any phishing-related keywords (e.g., 'urgent', 'pay', 'immediately', 'account', 'verify', etc.).
Below each sentence, explain why the identified keywords or phrasing might suggest phishing.
--------------------------
CHECK GRAMMAR AND SPELLING:
Analyze the entire email for grammar mistakes, spelling errors, or awkward phrasing. Provide specific examples and corrections where applicable.
--------------------------
OVERALL ANALYSIS:
Evaluate the email for common phishing tactics (e.g., social engineering, creating urgency, vague threats, or requests for sensitive information). Include any additional observations that support your assessment.
--------------------------
THE_FINAL_VERDICT:
State whether the email is likely phishing or not by 'PHISHING' or 'NOT PHISHING' and provide a brief justification based on your analysis.
Label it FINAL_VERDICT : ... and have a ! at the end of the final verdict. 
e.i, FINAL_VERDICT : Phishing!, FINAL_VERDICT : Not Phishing!, FINAL_VERDICT : Potentially Phishing!
-------------------------
Justification of the final verdict:
"""


#gemini function
def generate(message_check):
    client = genai.Client(
        api_key=os.environ.get("GEMINI_API_KEY"),
    )

    model = "gemini-2.0-flash-thinking-exp-01-21"
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_text(text=prompt + f" {message_check}"),
            ],
        ),
    ]
    generate_content_config = types.GenerateContentConfig(
        response_mime_type="text/plain",
        temperature =0.5, #control the creativty, so less liekly to create diffrent response
        top_p =0.9,
        top_k=40

    )

    g_response = ""
    for chunk in client.models.generate_content_stream(
        model=model,
        contents=contents,
        config=generate_content_config,
    ):
        #print(chunk.text, end="")
        g_response += chunk.text

    return g_response


#from gemini sample code

#if __name__ == "__main__":
    #generate("message_check")

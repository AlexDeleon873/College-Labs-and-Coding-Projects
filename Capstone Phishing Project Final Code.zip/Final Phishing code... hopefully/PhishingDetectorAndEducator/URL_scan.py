import os
import requests
from dotenv import load_dotenv
import time
import base64

# Load environment variables
load_dotenv()

# gets API key's from env file
VT_API = os.getenv("VT_API")
google_SB_API = os.getenv("google_SB_API")


#sends a post request for the specific url
def scan_url(url):
    base_url = "https://www.virustotal.com/api/v3/urls"
    payload_data = {"url": url}
    headers = {"x-apikey": VT_API,
               "Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(base_url, headers=headers, data=payload_data)

    #debugging
    if response.status_code == 200:
        analysis_id = response.json()["data"]["id"]
        url_id = response.json()["data"]["id"]
        print("checking " + analysis_id)
        return scan_url_result(analysis_id)
    else:
        print(f"Error from VirusTotal about scanning: {response.status_code} : {response.text}")
        return None

#a get request to get the analysis report
def scan_url_result(analysis_id):
    result_url = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"
    headers = {"x-apikey": VT_API,
               "accept": "application/json"
                }

    try:
        for attempts in range(3):
            time.sleep(5)
            response = requests.get(result_url, headers=headers)
            time.sleep(3)
    except Exception as e:
        print(f"Error from VirusTotal")
        return None


    response = requests.get(result_url, headers=headers)

    #debugging
    try:
        print(f"Getting results from {result_url}")
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error from VirusTotal about receiving: {response.status_code} : {response.text}")
            return None
    except Exception as e:
        print(f"Exception during results retrieval: {str(e)}")
        return None


#a get request to get the url report
def scan_url_report(url):
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    url_report = f"https://www.virustotal.com/api/v3/urls/{url_id}"
    headers = {"x-apikey": VT_API,
               "accept": "application/json"
               }

    report_response = requests.get(url_report, headers=headers)

    try:
        if report_response.status_code == 200:
            return report_response.json()
        else:
            print(f"Error from VirusTotal about receiving report: {report_response.status_code} : {report_response.text}")
            return None
    except Exception as e:
        print(f"Exception during results retrieval: {str(e)}")
        return None

#this is a post request getting info on the url from google safe browsing
def scan_url_gsb(url):
    base_url_GSB = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={google_SB_API}"
    body = {
            "client": {
                "clientId": "projectPhishing",
                "clientVersion": "1.0"
            },
            "threatInfo": {
                "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
                "platformTypes": ["WINDOWS"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [
                    {"url": url}
                ]
            }
        }
    response = requests.post(base_url_GSB, json=body)
    print(response.json())#see response in terminal
    return response.json()




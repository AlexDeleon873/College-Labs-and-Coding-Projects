import imaplib
import email
from email.header import decode_header
import os
from dotenv import load_dotenv

load_dotenv()

IMAP_SERVER = 'imap.gmail.com'
email_username = os.getenv("email_username")
email_password = os.getenv("email_password")

#------------------------------------------------
# conencting to imap ssl server
def fetch_emails():
    imap = imaplib.IMAP4_SSL(IMAP_SERVER) #initalized so we dont have to keep typing imaplib...

    imap.login(email_username, email_password)# logging in

    imap.select('INBOX')# selecting inbox mailbox

    #not adding filters for searching inbox
    check_status, msgnums = imap.search(None, "ALL")
    email_details = [] # create a list to hold data from email it self

    if check_status == "OK":
        for msgnum in msgnums[0].split():
            msgnum = msgnum.decode()  # Decode from bytes to string

            check_status, data = imap.fetch(msgnum, "(RFC822)")

            if check_status == "OK":
                #parsing the email content
                email_content = data[0][1]
                email_message = email.message_from_bytes(email_content)

                # decoding the subject
                subject, encoding = decode_header(email_message["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding or "utf-8")

                # getting the email body message
                content = ""
                if email_message.is_multipart():
                    for part in email_message.walk():
                        content_type = part.get_content_type()
                        content_disposition = str(part.get("Content-Disposition"))

                        if content_type == "text/plain" and "attachment" not in content_disposition:
                            content = part.get_payload(decode=True).decode(errors="ignore")
                            break  # Stop once we get plain text
                else:
                    content = email_message.get_payload(decode=True).decode(errors="ignore")

                # storing and appending email details to streamlit
                email_details.append({
                    'uid': msgnum,
                    'Subject': subject,
                    'From': email_message.get("From"),
                    'To': email_message.get("To"),
                    'Date': email_message.get('Date'),
                    'Content': content,
                })

    imap.close()
    imap.logout()
    return email_details


#TO be completed at a further date, made to delete emails directly in inbox after scan
"""
def delete_emails(uid):
    imap = imaplib.IMAP4_SSL(IMAP_SERVER)
    # logging in
    imap.login(email_username, email_password)
    # selecting inbox mailbox
    imap.select('INBOX')
    status, data = imap.search(None, "ALL")
    for uid in data[0].split():
        imap.uid('STORE',uid,'+X-GM-LABELS','\\Trash')
        #imap.store(uid, "+FLAGS", "\\Deleted")
    imap.expunge()
    imap.close()
    imap.logout()
"""

"""
def search_emails(imap):
    imap.select('INBOX')
    status, msgnums = imap.search(None, "search")
    imap.close()
    imap.logout()
"""

